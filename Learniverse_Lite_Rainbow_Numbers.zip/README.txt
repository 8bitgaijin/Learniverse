Licensing and Source Code Request Agreement
Game License

This software, Learniverse Lite: Rainbow Numbers, is proprietary software and is the intellectual property of Alvadore Retro Technology. By purchasing and downloading this game, you are granted a non-transferable, non-exclusive license to use the game for personal educational purposes only.

You may not:

    Modify, decompile, or reverse-engineer the game, except as permitted under the GNU Lesser General Public License (LGPL) version 2.1 with respect to Pygame.
    Redistribute or resell this game, in part or in full, without explicit written permission from Alvadore Retro Technology.

For more details about using the Pygame library and LGPL compliance, see below.
Pygame LGPL Compliance

This game uses the Pygame library, licensed under the GNU Lesser General Public License (LGPL) version 2.1. In compliance with the LGPL, we offer the option for customers to obtain the Python source code required to modify and relink the game with a modified version of Pygame.
Requesting the Source Code

If you are a customer who has purchased this game and would like to request the Python source code for the purpose of relinking the game with a modified version of Pygame, please contact us at [your email address].
Proof of Purchase

In your request, you must include valid proof of purchase, such as a receipt, order confirmation, or transaction ID. We reserve the right to verify your purchase before providing access to the source code. Requests without valid proof of purchase will not be processed.
Offer Validity

This offer to provide the source code is valid for three years from the official release date of the game. After this period, we may no longer be able to fulfill source code requests. The offer applies exclusively to customers who purchased the game within the availability window.
License and Usage Agreement for Source Code

By requesting and receiving the Python source code, you agree to the following terms:

    Purpose of Use: The source code is provided for personal use only, and specifically for modifying and relinking the game with a modified version of the Pygame library, as required by the LGPL.

    No Redistribution or Resale: You may not redistribute, share, publish, or resell the provided source code, either partially or fully. This includes, but is not limited to, sharing the source code with third parties, uploading it to public repositories, or selling modified versions of the game without our explicit written consent.

    Modification Restrictions: You are allowed to modify the source code solely for personal use and for relinking with Pygame. You are not permitted to use the modified code for any commercial purposes or distribute it in violation of this agreement.

    Legal Enforcement: Unauthorized distribution, resale, or misuse of the provided source code will result in legal action. We reserve the right to pursue all available legal remedies to protect our intellectual property.

Contact Information and Process

To request the source code, please send an email to [your email address] with the subject line: Source Code Request - [Your Game's Name]. In the email, please include:

    Your full name.
    Proof of purchase (receipt, order number, etc.).
    Your reason for requesting the source code (e.g., for relinking with a modified Pygame version).

Once we verify your proof of purchase, the Python source code will be provided via a secure method, such as a direct download link or email attachment.
PyInstaller Notice

This program was packaged using PyInstaller, which is licensed under the GNU General Public License (GPL) version 2 or later, with a special exception that allows distributing bundled programs under different licensing terms.

For more information about PyInstaller, visit:
https://github.com/pyinstaller/pyinstaller
Final Notes

This agreement is intended to fulfill LGPL compliance for providing source code while safeguarding the proprietary aspects of this game. We appreciate your understanding and adherence to these terms and thank you for supporting the game!